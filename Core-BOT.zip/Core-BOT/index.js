const {
  Client,
  GatewayIntentBits,
  Events,
  EmbedBuilder,
  PermissionFlagsBits,
  SlashCommandBuilder,
  InteractionContextType,
  MessageFlags,
  ActivityType
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // required for triggers
    GatewayIntentBits.GuildMembers
  ]
});

// ================= PERSISTENT SETTINGS (saved to settings.json) =================
const SETTINGS_FILE = path.join(__dirname, 'settings.json');
const DEFAULT_FOOTER = 'Tome • Core';
const DEFAULTS = {
  color: '#6400FF',
  footer: DEFAULT_FOOTER,
  image: null, // banner image URL
  thumbnail: null, // thumbnail logo URL
  status: 'online', // online | idle | dnd | invisible
  activityType: 'Custom', // Playing | Watching | Listening | Competing | Custom
  activityText: 'play.tome.fun | 19132'
};

function loadSettings() {
  try {
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) };
  } catch {
    return { ...DEFAULTS };
  }
}
const settings = loadSettings();

function saveSettings() {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2));
  } catch (err) {
    console.error('Could not save settings.json:', err.message);
  }
}

// Every embed made with this class automatically gets the saved colour + footer
class StyledEmbed extends EmbedBuilder {
  constructor(data) {
    super(data);
    this.setColor(parseInt(settings.color.replace('#', ''), 16));
    if (settings.footer) this.setFooter({ text: settings.footer });
  }
}

// Adds the banner image + thumbnail logo (used on panels: /dhelp, /announce)
function panel(embed) {
  if (settings.image) embed.setImage(settings.image);
  if (settings.thumbnail) embed.setThumbnail(settings.thumbnail);
  return embed;
}

function isValidUrl(str) {
  try {
    const u = new URL(str);
    return (u.protocol === 'http:' || u.protocol === 'https:') && str.length <= 2000;
  } catch {
    return false;
  }
}

function parseHex(input) {
  let m = input.trim().match(/^#?([0-9a-f]{6}|[0-9a-f]{3})$/i);
  if (!m) return null;
  let hex = m[1];
  if (hex.length === 3) hex = hex.split('').map((c) => c + c).join('');
  return '#' + hex.toUpperCase();
}

const ACTIVITY_TYPES = {
  Playing: ActivityType.Playing,
  Watching: ActivityType.Watching,
  Listening: ActivityType.Listening,
  Competing: ActivityType.Competing,
  Custom: ActivityType.Custom
};

function applyPresence() {
  if (!client.user) return;
  const type = ACTIVITY_TYPES[settings.activityType] ?? ActivityType.Custom;
  const activity =
    type === ActivityType.Custom
      ? { name: 'Custom Status', type, state: settings.activityText }
      : { name: settings.activityText, type };
  client.user.setPresence({ status: settings.status, activities: [activity] });
}
const warnings = new Map();
const triggers = new Map(); // name (lowercase) -> response

// ================= SLASH COMMAND DEFINITIONS =================
const adminOnly = (b) =>
  b
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setContexts(InteractionContextType.Guild);

const commands = [
  adminOnly(
    new SlashCommandBuilder()
      .setName('kick')
      .setDescription('Kick a member')
      .addUserOption((o) => o.setName('user').setDescription('Member to kick').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason'))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('ban')
      .setDescription('Permanently ban a member')
      .addUserOption((o) => o.setName('user').setDescription('Member to ban').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason'))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('tempban')
      .setDescription('Temporarily ban a member')
      .addUserOption((o) => o.setName('user').setDescription('Member to ban').setRequired(true))
      .addStringOption((o) =>
        o.setName('time').setDescription('Duration e.g. 10m, 1h, 7d').setRequired(true)
      )
      .addStringOption((o) => o.setName('reason').setDescription('Reason'))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('mute')
      .setDescription('Mute (timeout) a member')
      .addUserOption((o) => o.setName('user').setDescription('Member to mute').setRequired(true))
      .addStringOption((o) =>
        o.setName('time').setDescription('Duration e.g. 10m, 1h, 1d').setRequired(true)
      )
      .addStringOption((o) => o.setName('reason').setDescription('Reason'))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('warn')
      .setDescription('Warn a member')
      .addUserOption((o) => o.setName('user').setDescription('Member to warn').setRequired(true))
      .addStringOption((o) => o.setName('reason').setDescription('Reason'))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('clear')
      .setDescription('Delete messages (1-100)')
      .addIntegerOption((o) =>
        o
          .setName('amount')
          .setDescription('Number of messages')
          .setMinValue(1)
          .setMaxValue(100)
          .setRequired(true)
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('announce')
      .setDescription('Make an announcement')
      .addStringOption((o) =>
        o.setName('message').setDescription('Announcement text').setRequired(true)
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('trigger')
      .setDescription('Manage auto-reply triggers')
      .addSubcommand((s) =>
        s
          .setName('create')
          .setDescription('Create a trigger')
          .addStringOption((o) => o.setName('name').setDescription('Trigger word').setRequired(true))
          .addStringOption((o) =>
            o.setName('response').setDescription('Bot response').setRequired(true)
          )
      )
      .addSubcommand((s) =>
        s
          .setName('delete')
          .setDescription('Delete a trigger')
          .addStringOption((o) => o.setName('name').setDescription('Trigger word').setRequired(true))
      )
      .addSubcommand((s) => s.setName('list').setDescription('List all triggers'))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('dm')
      .setDescription('Send a DM to a member')
      .addUserOption((o) => o.setName('user').setDescription('Member to DM').setRequired(true))
      .addStringOption((o) => o.setName('message').setDescription('Message').setRequired(true))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('prvdm')
      .setDescription('Send an anonymous DM (sender name hidden)')
      .addUserOption((o) => o.setName('user').setDescription('Member to DM').setRequired(true))
      .addStringOption((o) => o.setName('message').setDescription('Message').setRequired(true))
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('image')
      .setDescription('Add a banner image to the panel')
      .addStringOption((o) =>
        o.setName('url').setDescription('Image URL (or "off" to remove)').setRequired(true)
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('fvn')
      .setDescription('Set the thumbnail logo (off to remove)')
      .addStringOption((o) =>
        o.setName('url').setDescription('Logo URL (or "off" to remove)').setRequired(true)
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('line')
      .setDescription('Change the embed colour (hex, e.g. #FF0000)')
      .addStringOption((o) =>
        o.setName('color').setDescription('Hex colour, e.g. #FF0000').setRequired(true)
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('ef')
      .setDescription('Edit the footer text (reset for default)')
      .addStringOption((o) =>
        o
          .setName('text')
          .setDescription('Footer text (or "reset" for default)')
          .setMaxLength(2048)
          .setRequired(true)
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('estatus')
      .setDescription('Set bot status: Online / Idle / DND / Invisible')
      .addStringOption((o) =>
        o
          .setName('status')
          .setDescription('Bot status')
          .setRequired(true)
          .addChoices(
            { name: 'Online', value: 'online' },
            { name: 'Idle', value: 'idle' },
            { name: 'Do Not Disturb', value: 'dnd' },
            { name: 'Invisible', value: 'invisible' }
          )
      )
  ),
  adminOnly(
    new SlashCommandBuilder()
      .setName('ebds')
      .setDescription('Set the status text and activity type')
      .addStringOption((o) =>
        o.setName('text').setDescription('Status text').setMaxLength(128).setRequired(true)
      )
      .addStringOption((o) =>
        o
          .setName('type')
          .setDescription('Activity type (default: Custom)')
          .addChoices(
            { name: 'Custom (plain text)', value: 'Custom' },
            { name: 'Playing', value: 'Playing' },
            { name: 'Watching', value: 'Watching' },
            { name: 'Listening to', value: 'Listening' },
            { name: 'Competing in', value: 'Competing' }
          )
      )
  ),
  adminOnly(new SlashCommandBuilder().setName('dhelp').setDescription('Show bot commands'))
].map((c) => c.toJSON());

async function registerCommands(guild) {
  try {
    await guild.commands.set(commands);
    console.log(`📌 Slash commands registered in: ${guild.name}`);
  } catch (err) {
    console.error(`Failed to register commands in ${guild.name}:`, err.message);
  }
}

client.once(Events.ClientReady, async () => {
  console.log(`✅ Logged in as ${client.user.tag}`);
  applyPresence(); // status + text are saved in settings.json (/estatus, /ebds)
  for (const guild of client.guilds.cache.values()) await registerCommands(guild);
});

client.on(Events.GuildCreate, registerCommands);

// ================= HELPERS =================
function parseTime(time) {
  if (!time) return null;
  const match = time.match(/^(\d+)(s|m|h|d|w)$/i);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  const multipliers = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000
  };
  return value * multipliers[unit];
}

async function sendDM(user, title, fields) {
  try {
    const embed = new StyledEmbed()
      .setTitle(title)
      .addFields(fields)
      .setTimestamp();
    await user.send({ embeds: [embed] });
  } catch (err) {}
}

function modEmbed(title, interaction, user, extra = [], reason) {
  const fields = [
    { name: 'User', value: `${user.tag}`, inline: true },
    { name: 'Moderator', value: `${interaction.user.tag}`, inline: true },
    ...extra
  ];
  if (reason !== undefined) fields.push({ name: 'Reason', value: reason });
  return new StyledEmbed().setTitle(title).addFields(fields).setTimestamp();
}

// ================= TRIGGERS (normal messages, no prefix) =================
client.on(Events.MessageCreate, async (message) => {
  if (message.author.bot || !message.guild) return;
  const content = message.content.trim().toLowerCase();
  if (triggers.has(content)) {
    await message.channel.send(triggers.get(content));
  }
});

// ================= SLASH COMMAND HANDLER =================
client.on(Events.InteractionCreate, async (interaction) => {
  if (!interaction.isChatInputCommand() || !interaction.guild) return;

  if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
    return interaction.reply({
      content: '❌ This command can only be used by **Administrators**.',
      flags: MessageFlags.Ephemeral
    });
  }

  const cmd = interaction.commandName;
  const fail = (msg) => {
    const payload = { content: msg, flags: MessageFlags.Ephemeral };
    return interaction.deferred || interaction.replied
      ? interaction.editReply({ content: msg })
      : interaction.reply(payload);
  };

  try {
    // ---------- KICK ----------
    if (cmd === 'kick') {
      const member = interaction.options.getMember('user');
      if (!member) return fail('❌ User is not in this server.');
      if (!member.kickable) return fail('❌ I cannot kick this user.');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      await interaction.deferReply();
      await member.kick(reason);
      await interaction.editReply({ embeds: [modEmbed('Member Kicked', interaction, member.user, [], reason)] });
      await sendDM(member.user, 'You have been kicked', [
        { name: 'Server', value: interaction.guild.name },
        { name: 'Reason', value: reason }
      ]);
    }

    // ---------- BAN ----------
    else if (cmd === 'ban') {
      const member = interaction.options.getMember('user');
      if (!member) return fail('❌ User is not in this server.');
      if (!member.bannable) return fail('❌ I cannot ban this user.');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      await interaction.deferReply();
      // Send the DM first, because a DM can't be sent after the ban
      await sendDM(member.user, 'You have been banned', [
        { name: 'Server', value: interaction.guild.name },
        { name: 'Reason', value: reason }
      ]);
      await member.ban({ reason });
      await interaction.editReply({ embeds: [modEmbed('Member Banned', interaction, member.user, [], reason)] });
    }

    // ---------- TEMPBAN ----------
    else if (cmd === 'tempban') {
      const member = interaction.options.getMember('user');
      if (!member) return fail('❌ User is not in this server.');
      if (!member.bannable) return fail('❌ I cannot ban this user.');
      const time = interaction.options.getString('time');
      const duration = parseTime(time);
      if (!duration) return fail('❌ Please provide a valid time. Example: `1m`, `1h`, `1d`, `7d`');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      await interaction.deferReply();
      await sendDM(member.user, 'You have been temporarily banned', [
        { name: 'Server', value: interaction.guild.name },
        { name: 'Duration', value: time },
        { name: 'Reason', value: reason }
      ]);
      await member.ban({ reason: `[TempBan ${time}] ${reason}` });
      await interaction.editReply({
        embeds: [modEmbed('Member Temporarily Banned', interaction, member.user, [{ name: 'Duration', value: time, inline: true }], reason)]
      });
      const channel = interaction.channel;
      const guild = interaction.guild;
      const userId = member.id;
      const tag = member.user.tag;
      // NOTE: setTimeout works for a maximum of ~24.8 days
      setTimeout(async () => {
        try {
          await guild.members.unban(userId, 'Tempban duration ended');
          channel.send(`✅ **${tag}**'s temporary ban has ended.`);
        } catch (e) {}
      }, Math.min(duration, 2147483647));
    }

    // ---------- MUTE ----------
    else if (cmd === 'mute') {
      const member = interaction.options.getMember('user');
      if (!member) return fail('❌ User is not in this server.');
      if (!member.moderatable) return fail('❌ I cannot mute this user.');
      const time = interaction.options.getString('time');
      const duration = parseTime(time);
      if (!duration) return fail('❌ Please provide a valid time. Example: `10m`, `1h`, `1d`');
      if (duration > 28 * 24 * 60 * 60 * 1000) return fail('❌ Maximum mute duration is 28 days.');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      await interaction.deferReply();
      await member.timeout(duration, reason);
      await interaction.editReply({
        embeds: [modEmbed('Member Muted', interaction, member.user, [{ name: 'Duration', value: time, inline: true }], reason)]
      });
      await sendDM(member.user, 'You have been muted', [
        { name: 'Server', value: interaction.guild.name },
        { name: 'Duration', value: time },
        { name: 'Reason', value: reason }
      ]);
    }

    // ---------- WARN ----------
    else if (cmd === 'warn') {
      const member = interaction.options.getMember('user');
      if (!member) return fail('❌ User is not in this server.');
      const reason = interaction.options.getString('reason') || 'No reason provided';
      if (!warnings.has(member.id)) warnings.set(member.id, []);
      warnings.get(member.id).push({
        reason,
        moderator: interaction.user.tag,
        date: new Date().toLocaleString()
      });
      const count = warnings.get(member.id).length;
      await interaction.reply({
        embeds: [modEmbed('Member Warned', interaction, member.user, [{ name: 'Total Warnings', value: `${count}`, inline: true }], reason)]
      });
      await sendDM(member.user, 'You have been warned', [
        { name: 'Server', value: interaction.guild.name },
        { name: 'Reason', value: reason },
        { name: 'Total Warnings', value: `${count}` }
      ]);
    }

    // ---------- CLEAR ----------
    else if (cmd === 'clear') {
      const amount = interaction.options.getInteger('amount');
      if (!interaction.channel.permissionsFor(interaction.guild.members.me).has(PermissionFlagsBits.ManageMessages)) {
        return fail('❌ I need the **Manage Messages** permission to delete messages.');
      }
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const deleted = await interaction.channel.bulkDelete(amount, true);
        await interaction.editReply({
          embeds: [
            new StyledEmbed()
              .setDescription(`✅ Successfully deleted **${deleted.size}** message(s).`)
              .setTimestamp()
          ]
        });
      } catch (err) {
        console.error(err);
        await interaction.editReply('❌ Failed to delete messages. Make sure the messages are not older than 14 days.');
      }
    }

    // ---------- ANNOUNCE ----------
    else if (cmd === 'announce') {
      const text = interaction.options.getString('message');
      const embed = panel(new StyledEmbed().setTitle('Announcement').setDescription(text));
      await interaction.channel.send({ embeds: [embed] });
      await interaction.reply({ content: '✅ Announcement sent.', flags: MessageFlags.Ephemeral });
    }

    // ---------- TRIGGER ----------
    else if (cmd === 'trigger') {
      const sub = interaction.options.getSubcommand();

      if (sub === 'create') {
        const name = interaction.options.getString('name');
        const response = interaction.options.getString('response');
        triggers.set(name.trim().toLowerCase(), response);
        const embed = new StyledEmbed()
          .setTitle('Trigger Created')
          .addFields(
            { name: 'Trigger', value: `\`${name}\``, inline: true },
            { name: 'Response', value: response }
          )
          .setTimestamp();
        await interaction.reply({ embeds: [embed] });
      } else if (sub === 'delete') {
        const name = interaction.options.getString('name');
        const key = name.trim().toLowerCase();
        if (!triggers.has(key)) return fail(`❌ Trigger \`${name}\` does not exist.`);
        triggers.delete(key);
        const embed = new StyledEmbed()
          .setTitle('Trigger Deleted')
          .setDescription(`Trigger \`${name}\` has been removed.`)
          .setTimestamp();
        await interaction.reply({ embeds: [embed] });
      } else if (sub === 'list') {
        if (triggers.size === 0) return fail('No triggers set yet.');
        const list = [...triggers.entries()].map(([n, r]) => `• **${n}** → ${r}`).join('\n');
        const embed = new StyledEmbed()
          .setTitle('Active Triggers')
          .setDescription(list.slice(0, 4000))
          .setFooter({ text: `${triggers.size} trigger(s)` })
          .setTimestamp();
        await interaction.reply({ embeds: [embed] });
      }
    }

    // ---------- DM (sender's name is included) ----------
    else if (cmd === 'dm') {
      const user = interaction.options.getUser('user');
      const text = interaction.options.getString('message');
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const embed = new StyledEmbed()
          .setTitle(`Message from ${interaction.guild.name}`)
          .setDescription(text)
          .addFields({
            name: 'Sent by',
            value: `${interaction.user.tag} (${interaction.member?.displayName ?? interaction.user.username})`
          })
          .setFooter({
            text: `Sent by ${interaction.user.tag}`,
            iconURL: interaction.user.displayAvatarURL()
          })
          .setTimestamp();
        await user.send({ embeds: [embed] });
        await interaction.editReply(`✅ DM sent to **${user.tag}**.`);
      } catch (err) {
        await interaction.editReply('❌ Could not DM this user. Their DMs might be closed.');
      }
    }

    // ---------- PRVDM (anonymous: message only, no sender name) ----------
    else if (cmd === 'prvdm') {
      const user = interaction.options.getUser('user');
      const text = interaction.options.getString('message');
      await interaction.deferReply({ flags: MessageFlags.Ephemeral });
      try {
        const embed = new StyledEmbed()
          .setTitle(`Message from ${interaction.guild.name}`)
          .setDescription(text)
          .setTimestamp(); // Discord automatically shows "Today at / Yesterday at 22:44"
        await user.send({ embeds: [embed] });
        await interaction.editReply(`✅ Private DM sent to **${user.tag}**.`);
      } catch (err) {
        await interaction.editReply('❌ Could not DM this user. Their DMs might be closed.');
      }
    }

    // ---------- IMAGE (banner) ----------
    else if (cmd === 'image') {
      const url = interaction.options.getString('url').trim();
      if (url.toLowerCase() === 'off') {
        settings.image = null;
        saveSettings();
        return interaction.reply({ content: '✅ Banner image removed.', flags: MessageFlags.Ephemeral });
      }
      if (!isValidUrl(url)) return fail('❌ Please provide a valid image URL (http/https), or `off` to remove.');
      settings.image = url;
      saveSettings();
      await interaction.reply({
        content: '✅ Banner image updated. Preview:',
        embeds: [new StyledEmbed().setDescription('Panel banner preview').setImage(url)],
        flags: MessageFlags.Ephemeral
      });
    }

    // ---------- FVN (thumbnail logo) ----------
    else if (cmd === 'fvn') {
      const url = interaction.options.getString('url').trim();
      if (url.toLowerCase() === 'off') {
        settings.thumbnail = null;
        saveSettings();
        return interaction.reply({ content: '✅ Thumbnail logo removed.', flags: MessageFlags.Ephemeral });
      }
      if (!isValidUrl(url)) return fail('❌ Please provide a valid image URL (http/https), or `off` to remove.');
      settings.thumbnail = url;
      saveSettings();
      await interaction.reply({
        content: '✅ Thumbnail logo updated. Preview:',
        embeds: [new StyledEmbed().setDescription('Thumbnail preview').setThumbnail(url)],
        flags: MessageFlags.Ephemeral
      });
    }

    // ---------- LINE (embed colour) ----------
    else if (cmd === 'line') {
      const hex = parseHex(interaction.options.getString('color'));
      if (!hex) return fail('❌ Invalid colour. Use a hex code like `#FF0000`.');
      settings.color = hex;
      saveSettings();
      await interaction.reply({
        content: `✅ Embed colour changed to \`${hex}\`.`,
        embeds: [new StyledEmbed().setDescription('Colour preview')],
        flags: MessageFlags.Ephemeral
      });
    }

    // ---------- EF (footer text) ----------
    else if (cmd === 'ef') {
      const text = interaction.options.getString('text').trim();
      settings.footer = text.toLowerCase() === 'reset' ? DEFAULT_FOOTER : text;
      saveSettings();
      await interaction.reply({
        content: text.toLowerCase() === 'reset' ? '✅ Footer reset to default.' : '✅ Footer updated.',
        embeds: [new StyledEmbed().setDescription('Footer preview')],
        flags: MessageFlags.Ephemeral
      });
    }

    // ---------- ESTATUS (online / idle / dnd / invisible) ----------
    else if (cmd === 'estatus') {
      settings.status = interaction.options.getString('status');
      saveSettings();
      applyPresence();
      const labels = { online: 'Online', idle: 'Idle', dnd: 'Do Not Disturb', invisible: 'Invisible' };
      await interaction.reply({
        content: `✅ Bot status set to **${labels[settings.status]}**.`,
        flags: MessageFlags.Ephemeral
      });
    }

    // ---------- EBDS (status text + activity type) ----------
    else if (cmd === 'ebds') {
      settings.activityText = interaction.options.getString('text').trim();
      settings.activityType = interaction.options.getString('type') || 'Custom';
      saveSettings();
      applyPresence();
      await interaction.reply({
        content: `✅ Status updated: **${settings.activityType}** → ${settings.activityText}`,
        flags: MessageFlags.Ephemeral
      });
    }

    // ---------- HELP ----------
    else if (cmd === 'help') {
      const embed = panel(new StyledEmbed())
        .setTitle('Bot Commands')
        .setDescription('Only **Administrators** can use these commands.')
        .addFields(
          {
            name: 'Moderation',
            value: [
              '`/kick user [reason]` - Kick a member',
              '`/ban user [reason]` - Permanently ban a member',
              '`/tempban user time [reason]` - Temporarily ban a member',
              '`/mute user time [reason]` - Mute a member',
              '`/warn user [reason]` - Warn a member'
            ].join('\n')
          },
          {
            name: 'Triggers',
            value: [
              '`/trigger create name response` - Create auto-reply trigger',
              '`/trigger delete name` - Delete a trigger',
              '`/trigger list` - List all triggers'
            ].join('\n')
          },
          {
            name: 'Utility',
            value: [
              '`/announce message` - Make an announcement',
              '`/dm user message` - Send a DM to a member (shows sender)',
              '`/prvdm user message` - Send an anonymous DM (sender hidden)',
              '`/clear amount` - Delete messages (1–100)',
              '`/dhelp` - Show this message'
            ].join('\n')
          },
          {
            name: 'Customisation',
            value: [
              '`/image url` - Add a banner image to the panel (`off` to remove)',
              '`/fvn url` - Set the thumbnail logo (`off` to remove)',
              '`/line color` - Change the embed colour (hex, e.g. `#FF0000`)',
              '`/ef text` - Edit the footer text (`reset` for default)',
              '`/estatus` - Set Online / Idle / DND / Invisible',
              '`/ebds text [type]` - Set the status text and activity type'
            ].join('\n')
          },
          {
            name: 'Time Examples',
            value: '`10m` = 10 minutes | `1h` = 1 hour | `1d` = 1 day | `7d` = 7 days'
          }
        );
      await interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    }
  } catch (err) {
    console.error(err);
    try {
      await fail('❌ Something went wrong while running this command.');
    } catch (e) {}
  }
});

// Keep the token in the TOKEN environment variable (or put your new token here)
client.login(process.env.TOKEN || 'YOUR_NEW_TOKEN_HERE');
